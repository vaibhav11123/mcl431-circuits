"""Lecture-locked drawings: stamp catalog glyphs, wire the ports."""

from __future__ import annotations

from pathlib import Path

from circuit.calc import solution_lines_for
from circuit.pack import call_hook
from circuit.draw_electrical import draw_electrical
from circuit.draw_hydraulic import draw_hydraulic
from circuit.draw_phase import draw_phase
from circuit.draw_plc import draw_plc_connection, draw_plc_ladder
from circuit.draw_pneumatic import draw_pneumatic
from circuit.spec import CircuitSpec, Domain
from circuit.svgdraw import SVG

__all__ = [
    "draw_all",
    "draw_calc_only",
    "draw_electrical",
    "draw_hydraulic",
    "draw_phase",
    "draw_pneumatic",
    "draw_plc_connection",
    "draw_plc_ladder",
    "write_solution",
]


def _write_plc_solution(spec: CircuitSpec, dest: Path) -> Path:
    lines = [spec.meta.title, "", "I/O"]
    if spec.plc:
        for row in spec.plc.io:
            lines.append(f"  {row.address}  {row.device}  — {row.function}")
    lines += ["", "Calculations / notes"]
    lines.extend(f"  {ln}" for ln in solution_lines_for(spec.meta.exam_id))
    lines.extend(call_hook("solution_extra", spec, default=[]) or [])
    if spec.plc and spec.plc.notes:
        lines += ["", "Ladder notes"]
        lines.extend(f"  {n}" for n in spec.plc.notes)
    lines += ["", "Components", "  PLC sheet — no hydraulic pump/valves"]
    dest.write_text("\n".join(lines) + "\n")
    return dest


def write_solution(spec: CircuitSpec, dest: Path) -> Path:
    dest.parent.mkdir(parents=True, exist_ok=True)
    if spec.meta.domain == Domain.PLC:
        return _write_plc_solution(spec, dest)
    lines = [spec.meta.title, "", "Sequence"]
    for i, step in enumerate(spec.sequence, 1):
        extra = f" ({step.seconds} s)" if step.seconds else ""
        lines.append(f"  {i}. {step.action}{extra} — {step.label}")
    lines += ["", "Calculations (lecture forms; no invented Q)"]
    lines.extend(f"  {ln}" for ln in solution_lines_for(spec.meta.exam_id))
    lines.extend(call_hook("solution_extra", spec, default=[]) or [])
    lines += ["", "Components"]
    for p in spec.power.pumps:
        lines.append(f"  pump {p.id}")
    for r in spec.power.relief_valves:
        lines.append(f"  relief {r.id}")
    for cid, cyl in spec.cylinders.items():
        bore = "not_given" if cyl.bore_mm is None else cyl.bore_mm
        rod = "not_given" if cyl.rod_mm is None else cyl.rod_mm
        lines.append(f"  {cid} bore {bore} rod {rod} dcv {cyl.dcv}")
    for mid, mot in spec.motors.items():
        lines.append(f"  {mid} rpm {mot.rpm} dcv {mot.dcv}")
    dest.write_text("\n".join(lines) + "\n")
    return dest


def draw_calc_only(spec: CircuitSpec, dest: Path) -> Path:
    dest.parent.mkdir(parents=True, exist_ok=True)
    s = SVG(820, 220)
    s.text(410, 70, spec.meta.title, 16)
    s.text(410, 110, "Figure given on the paper — calc only", 14)
    s.text(410, 150, spec.meta.exam_id or "", 12)
    dest.write_text(s.tostring())
    return dest


def watermark_written(written: dict[str, Path]) -> None:
    from circuit.svgdraw import watermark_svg

    for path in written.values():
        if getattr(path, "suffix", "") == ".svg" and path.is_file():
            path.write_text(watermark_svg(path.read_text(encoding="utf-8")))


def draw_all(spec: CircuitSpec, out_dir: Path, *, verified=None) -> dict[str, Path]:
    if verified is not None:
        spec = verified.spec
        from circuit.compile_sequence import rendering_verified

        with rendering_verified():
            return _draw_all_body(spec, out_dir)
    return _draw_all_body(spec, out_dir)


def _draw_all_body(spec: CircuitSpec, out_dir: Path) -> dict[str, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    if spec.meta.figure_given:
        written = {
            "calc": draw_calc_only(spec, out_dir / "calc_only.svg"),
            "solution": write_solution(spec, out_dir / "solution.txt"),
        }
        try:
            from circuit.png import svg_to_png
        except ImportError:
            svg_to_png = None  # type: ignore[assignment]
        if svg_to_png is not None:
            png = svg_to_png(written["calc"])
            if png is not None:
                written["calc_png"] = png
        return written
    if spec.meta.domain == Domain.PLC:
        written = {
            "solution": write_solution(spec, out_dir / "solution.txt"),
            "connection": draw_plc_connection(spec, out_dir / "plc_connection.svg"),
            "ladder": draw_plc_ladder(spec, out_dir / "plc_ladder.svg"),
        }
        try:
            from circuit.png import svg_to_png
        except ImportError:
            svg_to_png = None  # type: ignore[assignment]
        pngs: dict[str, Path] = {}
        if svg_to_png is not None:
            for key in ("connection", "ladder"):
                png = svg_to_png(written[key])
                if png is not None:
                    pngs[f"{key}_png"] = png
        if not pngs:
            print("PNG skipped: install librsvg or use macOS")
        written.update(pngs)
        return written
    ep = spec.meta.domain in {
        Domain.HYDRAULIC_PLUS_ELECTRICAL,
        Domain.PNEUMATIC_PLUS_ELECTRICAL,
    }
    pneu = spec.meta.domain in {Domain.PNEUMATIC, Domain.PNEUMATIC_PLUS_ELECTRICAL}
    written: dict[str, Path] = {
        "solution": write_solution(spec, out_dir / "solution.txt"),
    }
    if ep:
        written["electrical"] = draw_electrical(spec, out_dir / "electrical_circuit.svg")
        written["phase"] = draw_phase(spec, out_dir / "step_displacement.svg")
    if pneu:
        written["pneumatic"] = draw_pneumatic(spec, out_dir / "pneumatic_circuit.svg")
    else:
        written["hydraulic"] = draw_hydraulic(spec, out_dir / "hydraulic_circuit.svg")
    try:
        from circuit.png import svg_to_png
    except ImportError:
        svg_to_png = None  # type: ignore[assignment]
    pngs: dict[str, Path] = {}
    if svg_to_png is not None:
        for key in ("hydraulic", "pneumatic", "electrical", "phase"):
            if key not in written:
                continue
            png = svg_to_png(written[key])
            if png is not None:
                pngs[f"{key}_png"] = png
    if not pngs:
        print("PNG skipped: install librsvg or use macOS")
    written.update(pngs)
    return written
